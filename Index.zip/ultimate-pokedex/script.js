const API = "https://pokeapi.co/api/v2";
const grid = document.getElementById("pokemonGrid");
const statusBox = document.getElementById("status");
const searchInput = document.getElementById("searchInput");
const typeFilter = document.getElementById("typeFilter");
const generationFilter = document.getElementById("generationFilter");
const sortFilter = document.getElementById("sortFilter");
const loadMoreBtn = document.getElementById("loadMore");
const modal = document.getElementById("detailModal");
const detailContent = document.getElementById("detailContent");

const generationRanges = {1:[1,151],2:[152,251],3:[252,386],4:[387,493],5:[494,649],6:[650,721],7:[722,809],8:[810,905],9:[906,1025]};
const typeColors = {normal:"#a8a77a",fire:"#ee8130",water:"#6390f0",electric:"#f7d02c",grass:"#7ac74c",ice:"#96d9d6",fighting:"#c22e28",poison:"#a33ea1",ground:"#e2bf65",flying:"#a98ff3",psychic:"#f95587",bug:"#a6b91a",rock:"#b6a136",ghost:"#735797",dragon:"#6f35fc",dark:"#705746",steel:"#b7b7ce",fairy:"#d685ad"};
const generationById = id => Object.entries(generationRanges).find(([,r])=>id>=r[0]&&id<=r[1])?.[0] || "9";
let pokemon = [];
let nextOffset = 0;
let currentLimit = 36;
let showingFavorites = false;
let favorites = new Set(JSON.parse(localStorage.getItem("pokedex-favorites") || "[]"));
let searchTimer;

function titleCase(s){return s.charAt(0).toUpperCase()+s.slice(1)}
function imageFor(id){return `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${id}.png`}
function typePill(type){return `<span class="type-pill" style="background:${typeColors[type]||"#888"}">${type}</span>`}
function setStatus(message, show=true){statusBox.textContent=message;statusBox.style.display=show?"block":"none"}
function updateFavoriteCount(){document.getElementById("favoriteCount").textContent=favorites.size}
function saveFavorites(){localStorage.setItem("pokedex-favorites",JSON.stringify([...favorites]));updateFavoriteCount()}
function cardTemplate(p){
  const types=p.types.map(t=>t.type.name);
  const tint=typeColors[types[0]]||"#eee";
  return `<article class="pokemon-card" style="--tint:${tint}22" data-id="${p.id}" tabindex="0" role="button" aria-label="View ${p.name}">
    <div class="card-top"><span class="poke-number">#${String(p.id).padStart(4,"0")}</span><button class="favorite-btn ${favorites.has(p.id)?"active":""}" data-fav="${p.id}" aria-label="Toggle favorite">${favorites.has(p.id)?"♥":"♡"}</button></div>
    <div class="pokemon-art"><img loading="lazy" src="${imageFor(p.id)}" alt="${p.name}" onerror="this.src='https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${p.id}.png'"></div>
    <h3>${p.name.replace(/-/g," ")}</h3><div class="types">${types.map(typePill).join("")}</div>
    <div class="card-bottom"><span>GENERATION ${generationById(p.id)}</span><span>VIEW DETAILS ↗</span></div>
  </article>`;
}
function render(){
  const query=searchInput.value.trim().toLowerCase();
  let list=pokemon.filter(p=>{
    const matchesName=p.name.includes(query)||String(p.id)===query;
    const matchesType=!typeFilter.value||p.types.some(t=>t.type.name===typeFilter.value);
    const gen=generationFilter.value;
    const matchesGen=!gen||generationById(p.id)===gen;
    const matchesFav=!showingFavorites||favorites.has(p.id);
    return matchesName&&matchesType&&matchesGen&&matchesFav;
  });
  if(sortFilter.value==="name")list.sort((a,b)=>a.name.localeCompare(b.name));
  else list.sort((a,b)=>a.id-b.id);
  grid.innerHTML=list.map(cardTemplate).join("");
  document.getElementById("resultCount").textContent=`Showing ${list.length} Pokémon`;
  document.getElementById("resultsTitle").textContent=showingFavorites?"Your favorites":"Pokémon collection";
  loadMoreBtn.hidden=showingFavorites||Boolean(query)||Boolean(typeFilter.value)||Boolean(generationFilter.value)||nextOffset>=1025;
  if(!list.length)setStatus(showingFavorites?"No favorites yet. Tap the heart on a Pokémon to save it.":"No Pokémon found. Try changing your search or filters.");
  else setStatus("",false);
}
async function loadTypes(){
  try{const r=await fetch(`${API}/type`);const d=await r.json();d.results.filter(x=>!["unknown","shadow"].includes(x.name)).forEach(t=>{const o=document.createElement("option");o.value=t.name;o.textContent=titleCase(t.name);typeFilter.appendChild(o)})}catch(e){console.warn("Could not load type list",e)}
}
async function loadBatch(){
  loadMoreBtn.disabled=true;loadMoreBtn.textContent="Loading…";
  setStatus("Loading Pokémon from the PokéAPI…");
  try{
    const r=await fetch(`${API}/pokemon?limit=${currentLimit}&offset=${nextOffset}`);
    if(!r.ok)throw new Error("PokéAPI request failed");
    const d=await r.json();
    const details=await Promise.all(d.results.map(async item=>{const response=await fetch(item.url);return response.json()}));
    pokemon.push(...details);nextOffset+=d.results.length;render();
  }catch(e){setStatus("Unable to load Pokémon. Please check your internet connection and try again.");console.error(e)}
  loadMoreBtn.disabled=false;loadMoreBtn.textContent="Load more Pokémon";
}
async function fetchPokemon(idOrName){
  const r=await fetch(`${API}/pokemon/${encodeURIComponent(idOrName)}`);
  if(!r.ok)throw new Error("Pokémon not found");
  return r.json();
}
async function openDetails(id){
  modal.classList.add("open");modal.setAttribute("aria-hidden","false");document.body.style.overflow="hidden";
  detailContent.innerHTML='<div class="status"><span class="loader"></span>Loading Pokémon documentation…</div>';
  try{
    const p=await fetchPokemon(id);
    const [species, evolution]=await Promise.all([fetch(p.species.url).then(r=>r.json()),fetch(p.species.url).then(r=>r.json()).then(s=>fetch(s.evolution_chain.url).then(r=>r.json()))]);
    const flavor=species.flavor_text_entries.find(x=>x.language.name==="en")?.flavor_text.replace(/[\n\f]/g," ")||"No Pokédex description available.";
    const stats=p.stats.map(s=>`<div class="stat-row"><span>${s.stat.name.replace("-"," ")}</span><strong>${s.base_stat}</strong><div class="stat-track"><div class="stat-fill" style="width:${Math.min(100,s.base_stat/255*100)}%"></div></div></div>`).join("");
    const abilities=p.abilities.map(a=>`<span class="ability-chip">${a.ability.name.replace(/-/g," ")}${a.is_hidden?" · hidden":""}</span>`).join("");
    const chain=flattenEvolution(evolution.chain);
    const evoHtml=chain.length>1?chain.map((item,i)=>`${i?'<span class="evo-arrow">→</span>':""}<div class="evo-item"><img loading="lazy" src="${imageFor(item.id)}" alt="${item.name}">${item.name.replace(/-/g," ")}</div>`).join(""):"<p class='description'>This Pokémon has no recorded evolution chain.</p>";
    const types=p.types.map(t=>t.type.name);
    const tint=(typeColors[types[0]]||"#eee")+"22";
    detailContent.innerHTML=`
      <section class="detail-hero" style="--detail-tint:${tint}">
        <div><p class="eyebrow">NATIONAL POKÉDEX #${String(p.id).padStart(4,"0")}</p><h2 id="detailName">${p.name.replace(/-/g," ")}</h2><div class="types">${types.map(typePill).join("")}</div></div>
        <img src="${imageFor(p.id)}" alt="${p.name}">
      </section>
      <section class="detail-body">
        <h3>Pokédex entry</h3><p class="description">${flavor}</p>
        <div class="quick-facts"><div class="fact"><strong>${(p.height/10).toFixed(1)} m</strong><span>Height</span></div><div class="fact"><strong>${(p.weight/10).toFixed(1)} kg</strong><span>Weight</span></div><div class="fact"><strong>${p.base_experience??"—"}</strong><span>Base XP</span></div><div class="fact"><strong>Gen ${generationById(p.id)}</strong><span>Generation</span></div></div>
        <h3>Base stats</h3>${stats}
        <h3>Abilities</h3><div class="ability-list">${abilities}</div>
        <h3>Evolution chain</h3><div class="evolution">${evoHtml}</div>
        <h3>Pokémon data</h3><p class="description">Species: ${species.genera.find(g=>g.language.name==="en")?.genus||"Unknown"} · Capture rate: ${species.capture_rate} · Habitat: ${species.habitat?.name||"Unknown"} · Legendary: ${species.is_legendary?"Yes":"No"} · Mythical: ${species.is_mythical?"Yes":"No"}</p>
      </section>`;
  }catch(e){detailContent.innerHTML='<div class="error">Could not load this Pokémon. Please try again.</div>';console.error(e)}
}
function flattenEvolution(node,out=[]){
  const match=node.species.url.match(/\/pokemon-species\/(\d+)\//);
  out.push({name:node.species.name,id:Number(match?.[1]||0)});
  if(node.evolves_to.length)flattenEvolution(node.evolves_to[0],out);
  return out;
}
function closeDetails(){modal.classList.remove("open");modal.setAttribute("aria-hidden","true");document.body.style.overflow=""}

grid.addEventListener("click",e=>{
  const fav=e.target.closest("[data-fav]");
  if(fav){const id=Number(fav.dataset.fav);favorites.has(id)?favorites.delete(id):favorites.add(id);saveFavorites();render();return}
  const card=e.target.closest("[data-id]");if(card)openDetails(card.dataset.id);
});
grid.addEventListener("keydown",e=>{if((e.key==="Enter"||e.key===" ")&&e.target.matches("[data-id]")){e.preventDefault();openDetails(e.target.dataset.id)}});
searchInput.addEventListener("input",()=>{clearTimeout(searchTimer);searchTimer=setTimeout(render,120)});
document.getElementById("searchClear").addEventListener("click",()=>{searchInput.value="";render();searchInput.focus()});
[typeFilter,generationFilter,sortFilter].forEach(el=>el.addEventListener("change",render));
document.getElementById("favoritesToggle").addEventListener("click",()=>{showingFavorites=!showingFavorites;document.getElementById("favoritesToggle").classList.toggle("active",showingFavorites);render()});
document.getElementById("favoritesOnly").addEventListener("change",e=>{showingFavorites=e.target.checked;render()});
document.getElementById("resetFilters").addEventListener("click",()=>{searchInput.value="";typeFilter.value="";generationFilter.value="";sortFilter.value="id";showingFavorites=false;document.getElementById("favoritesOnly").checked=false;render()});
loadMoreBtn.addEventListener("click",loadBatch);
document.getElementById("closeModal").addEventListener("click",closeDetails);
modal.addEventListener("click",e=>{if(e.target.dataset.close==="true")closeDetails()});
document.addEventListener("keydown",e=>{if(e.key==="Escape")closeDetails()});
updateFavoriteCount();loadTypes();loadBatch();
