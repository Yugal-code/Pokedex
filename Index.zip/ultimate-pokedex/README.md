# Ultimate Pokédex

A responsive Pokémon encyclopedia website built with plain HTML, CSS and JavaScript.

## Run locally
1. Download and extract the ZIP.
2. Open `index.html` in a modern browser.
3. Keep an internet connection available: Pokémon data is loaded from the public PokéAPI.

For a local development server, you can also run:
```bash
python -m http.server 8000
```
Then visit `http://localhost:8000`.

## Deploy to GitHub Pages
1. Create a new GitHub repository.
2. Upload `index.html`, `style.css`, `script.js`, and `README.md` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select `main` and `/ (root)`, then save.
6. Wait for GitHub Pages to publish your site.

## Features
- Responsive layout for phones, tablets and laptops
- Pokémon listing loaded in batches from PokéAPI
- Search by Pokémon name or Pokédex number
- Type, generation and name/number sorting filters
- Favorites saved in browser local storage
- Detail view with Pokédex description, types, height, weight, base stats, abilities, evolution chain and species information

## Data and attribution
Pokémon data is provided by [PokéAPI](https://pokeapi.co/). Pokémon and Pokémon character names are trademarks of Nintendo, Game Freak and The Pokémon Company.

## Notes
- An internet connection is required to fetch Pokémon data and artwork.
- Favorites are stored in the current browser on the current device.
- The app loads Pokémon in batches to avoid fetching the entire Pokédex at once.
